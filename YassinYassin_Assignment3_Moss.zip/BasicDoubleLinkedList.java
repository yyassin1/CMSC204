import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.ListIterator;
/**
 * 
 * @author Yassin Yassin
 * 
 * @param <T>
 */
public class BasicDoubleLinkedList<T> implements Iterable<T> {

	protected int size;
	protected Node<T> head;
	protected Node<T> tail;

	protected class Node<T> {
		protected T data;
		protected Node<T> next;
		protected Node<T> prev;

		protected Node(T data) {
			this.data = data;

		}
	}

	public BasicDoubleLinkedList() {
		this.size = 0;
		this.head = null;
		this.tail = null;
	}

	/**
	 * @return True is list is empty
	 */
	public boolean isEmpty() {
		return size == 0; // head is null
	}

	/** 
	 * @return The size of the linked list
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Adds an element to the front of the list.
	 * 
	 * @param data The data for the node within the linked list
	 * @return Reference to the current object
	 */
	public BasicDoubleLinkedList<T> addToEnd(T data) {
		Node<T> newNode = new Node<T>(data);

		if (isEmpty()) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;
		}
		size++;

		return this;
	}

	/**
	 * Adds an element to the front of the list.
	 * @param data
	 * @return Reference to the current object
	 */
	public BasicDoubleLinkedList<T> addToFront(T data) {
		Node<T> newNode = new Node<T>(data);

		if (isEmpty()) {
			head = newNode;
			tail = newNode;
		} else {
			head.prev = newNode;
			newNode.next = head;
			head = newNode;
		}
		size++;

		return this;
	}

	/**
	 * Returns but does not remove the first element from the list.
	 * 
	 * @return T Generic object
	 */
	public T getFirst() {
		if (isEmpty()) {
			return null;
		}

		return head.data;
	}

	/**
	 * Returns but does not remove the last element from the list.
	 * 
	 * @return T Generic object
	 */
	public T getLast() {
		if (isEmpty()) {
			return null;
		}

		return tail.data;
	}

	/**
	 * @throws NoSuchElementException        
	 * @throws UnsupportedOperationException
	 */
	@Override
	public ListIterator<T> iterator() {

		return new ListIterator<T>() {

			Node<T> current = head;
			Node<T> lastMove = null;

			@Override
			public boolean hasNext() {

				return current != null;
			}

			@Override
			public T next() throws NoSuchElementException {
				if (!hasNext()) {
					throw new NoSuchElementException();
				}
				T currentData = current.data;
				lastMove = current;
				current = current.next;
				return currentData;
			}

			public boolean hasPrevious() {
				return lastMove != null;
			}

			public T previous() throws NoSuchElementException {
				if (!hasPrevious()) {
					throw new NoSuchElementException();
				}
				T previousData = lastMove.data;
				current = lastMove;
				lastMove = lastMove.prev;
				return previousData;
			}

			@Override
			public void add(T e) {
				throw new UnsupportedOperationException();

			}

			@Override
			public int nextIndex() {
				throw new UnsupportedOperationException();
			}

			@Override
			public int previousIndex() {
				throw new UnsupportedOperationException();
			}

			@Override
			public void remove() {
				throw new UnsupportedOperationException();

			}

			@Override
			public void set(T e) {
				throw new UnsupportedOperationException();

			}

		};
	}

	/**
	 * Removes the first instance of the targetData from the list.
	 * 
	 * @param targetData
	 * @param comparator
	 * @return
	 */
	
	public BasicDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator) {
		Node<T> current = head;
		while (current != null) {
			if (comparator.compare(targetData, current.data) == 0) {
				if (current == head) {
					head = head.next;
					size--;
					break;
				} else if (current == tail) {
					tail = tail.prev;
					tail.next = null;
					size--;
					break;
				} else {
					current.prev.next = current.next;
					current.next.prev = current.prev;
					size--;
					break;
				}

			}
			current = current.next;

		}

		return this;
	}

	/**
	 * Removes and returns the first element from the list.
	 * 
	 * @return Data element or null
	 */
	public T retrieveFirstElement() {
		if (isEmpty()) {
			return null;
		}
		T firstData = head.data;
		head = head.next;
		head.prev = null;
		size--;
		return firstData;
	}

	/**
	 * Removes and returns the last element from the list.
	 * 
	 * @return Data element or null
	 */
	public T retrieveLastElement() {
		if (isEmpty()) {
			return null;
		}
		T lastData = tail.data;
		tail = tail.prev;
		tail.next = null;
		size--;
		return lastData;
	}

	/**
	 * Returns an arraylist of the items in the list from head of list to tail of
	 * list
	 * 
	 * @return An arraylist of the items in the list
	 */
	public ArrayList<T> toArrayList() {
		ArrayList<T> list = new ArrayList<T>(getSize());

		Node<T> current = head;

		while (current != null) {
			list.add(current.data);
			current = current.next;
		}

		return list;
	}

}